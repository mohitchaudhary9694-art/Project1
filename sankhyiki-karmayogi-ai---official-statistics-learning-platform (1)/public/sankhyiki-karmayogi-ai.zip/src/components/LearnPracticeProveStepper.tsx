import React from 'react';
import { 
  BookOpen, 
  Code2, 
  Award, 
  BarChart3, 
  Sparkles, 
  ArrowRight, 
  CheckCircle2, 
  Play
} from 'lucide-react';

export type LearningStage = 'learn' | 'practice' | 'prove' | 'measure' | 'improve';

interface LearnPracticeProveStepperProps {
  currentStage: LearningStage;
  onNavigateStage: (stage: LearningStage) => void;
  completedStages?: LearningStage[];
  officerName: string;
}

interface StageInfo {
  id: LearningStage;
  label: string;
  sublabel: string;
  icon: React.ElementType;
  description: string;
  actionText: string;
  metric: string;
}

export const STAGES: StageInfo[] = [
  {
    id: 'learn',
    label: '1. Learn',
    sublabel: 'iGOT & NSSTA Courses',
    icon: BookOpen,
    description: 'Acquire official MoSPI competencies via accredited digital modules and TPAC curriculum.',
    actionText: 'Explore Courses',
    metric: '3 In-Progress',
  },
  {
    id: 'practice',
    label: '2. Practice',
    sublabel: 'RAG Assistant & Labs',
    icon: Code2,
    description: 'Query official survey manuals, test Python code pipelines, and study methodological SOPs.',
    actionText: 'Open Assistant',
    metric: '12 Queries Run',
  },
  {
    id: 'prove',
    label: '3. Prove',
    sublabel: 'AI Quiz Studio',
    icon: Award,
    description: 'Demonstrate subject mastery through proctored MCQs and adaptive competency assessments.',
    actionText: 'Take AI Test',
    metric: '4 Tests Passed',
  },
  {
    id: 'measure',
    label: '4. Measure',
    sublabel: 'Gap Analysis Engine',
    icon: BarChart3,
    description: 'Evaluate proficiency against designated cadre benchmarks and identify high-priority gaps.',
    actionText: 'View Gaps',
    metric: '68% Readiness',
  },
  {
    id: 'improve',
    label: '5. Improve',
    sublabel: 'Competency Passport',
    icon: Sparkles,
    description: 'Earn verifiable digital credentials, track upward skill velocity, and unlock career milestones.',
    actionText: 'Open Passport',
    metric: '6 Badges Earned',
  }
];

export const LearnPracticeProveStepper: React.FC<LearnPracticeProveStepperProps> = ({
  currentStage,
  onNavigateStage,
  completedStages = ['learn', 'practice'],
}) => {
  const currentIndex = STAGES.findIndex(s => s.id === currentStage);

  return (
    <div className="space-y-4">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-blue-50 border border-blue-100 text-[#1E3ABA] text-[11px] font-bold uppercase tracking-wider">
              StatSkill Continuous Learning Cycle
            </span>
            <span className="text-xs text-slate-500 font-medium hidden sm:inline">
              Learn → Practice → Prove → Measure → Improve
            </span>
          </div>
          <h3 className="text-base sm:text-lg font-bold text-slate-900 mt-1 flex items-center gap-2 font-heading">
            Competency Mastery Pathway
          </h3>
        </div>

        {/* Current Active Step Banner */}
        <div className="flex items-center gap-2 self-start sm:self-auto bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#1E3ABA] opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-[#1E3ABA]"></span>
          </span>
          <span className="text-xs font-semibold text-slate-700">
            Active Stage: <strong className="text-[#1E3ABA]">{STAGES[currentIndex]?.label}</strong>
          </span>
        </div>
      </div>

      {/* Horizontal Stepper Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {STAGES.map((stage, idx) => {
          const Icon = stage.icon;
          const isActive = stage.id === currentStage;
          const isCompleted = completedStages.includes(stage.id) && !isActive;
          const isPast = idx < currentIndex;

          return (
            <button
              key={stage.id}
              type="button"
              onClick={() => onNavigateStage(stage.id)}
              className={`text-left p-3.5 rounded-lg transition-all relative border cursor-pointer group flex flex-col justify-between ${
                isActive
                  ? 'bg-blue-50/70 border-[#1E3ABA] shadow-xs ring-1 ring-[#1E3ABA]/30'
                  : isCompleted || isPast
                  ? 'bg-emerald-50/40 border-emerald-200 hover:border-emerald-400 hover:bg-emerald-50/70'
                  : 'bg-slate-50 border-slate-200 hover:border-slate-300 hover:bg-slate-100/70'
              }`}
            >
              {/* Top Row: Icon & Status */}
              <div className="flex items-center justify-between mb-2">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition ${
                  isActive
                    ? 'bg-[#1E3ABA] text-white'
                    : isCompleted || isPast
                    ? 'bg-emerald-100 text-emerald-700'
                    : 'bg-slate-200 text-slate-600 group-hover:text-slate-900'
                }`}>
                  <Icon className="w-4 h-4" />
                </div>

                {isCompleted || isPast ? (
                  <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded">
                    <CheckCircle2 className="w-3 h-3" />
                    Done
                  </span>
                ) : isActive ? (
                  <span className="flex items-center gap-1 text-[10px] font-bold text-[#1E3ABA] bg-blue-100 px-1.5 py-0.5 rounded">
                    <Play className="w-2.5 h-2.5 fill-current" />
                    Active
                  </span>
                ) : (
                  <span className="text-[10px] text-slate-500 font-mono">
                    Step {idx + 1}
                  </span>
                )}
              </div>

              {/* Middle: Labels */}
              <div>
                <div className={`text-xs font-bold transition ${
                  isActive ? 'text-[#1E3ABA]' : 'text-slate-900'
                }`}>
                  {stage.label}
                </div>
                <div className="text-[11px] text-slate-600 font-medium mt-0.5 leading-tight">
                  {stage.sublabel}
                </div>
                <p className="text-[10px] text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                  {stage.description}
                </p>
              </div>

              {/* Bottom: Action Trigger */}
              <div className="mt-3 pt-2 border-t border-slate-200/80 flex items-center justify-between text-[10px]">
                <span className="text-slate-500 font-mono">
                  {stage.metric}
                </span>
                <span className={`font-semibold flex items-center gap-1 transition ${
                  isActive ? 'text-[#1E3ABA]' : 'text-slate-600 group-hover:text-slate-900'
                }`}>
                  {stage.actionText}
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
